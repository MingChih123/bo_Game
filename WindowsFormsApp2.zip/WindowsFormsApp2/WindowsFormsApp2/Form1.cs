﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Data.SqlClient;
using System.Reflection.Emit;
using WMPLib;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        //宣告音效
        WMPLib.WindowsMediaPlayer wplayer = new WMPLib.WindowsMediaPlayer();
        SoundPlayer sp2 = new SoundPlayer("bo.wav"); //消對方塊的音效
        SoundPlayer sp3 = new SoundPlayer("ha.wav"); //消錯方塊的音效

        //宣告玩家 / 方塊
        int drum_number = 3; //三個軌道
        int note_number = 7; //畫面上出現的方塊數
        int sc = 0; //初始消除方塊數為 0
        private Random rnd = new Random(Guid.NewGuid().GetHashCode()); //亂數種子設定：決定方塊顏色、位置
        PictureBox[] drum = new PictureBox[10];
        PictureBox[] note = new PictureBox[15];

        //宣告狀態
        int now = 6; //畫面上正要消除的方塊編號
        bool hita = false, hits = false, hitd = false; //目前玩家的按鍵狀態
        bool jump = false; //是否進行銷錯方塊的懲罰
        bool up = false; //是否正在消錯方塊的懲罰狀態

        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
            DoubleBuffered = true;
            this.SetBounds(0, 0, 600, 900);  //設定邊界 0, 0, 1080, 750
            label1.Location = new Point(220, 770);
            label2.Location = new Point(10, 825);
            label1.Text = "Now : " + sc.ToString();
            label2.Text = "[A][S][D]消除方塊 [R]分數歸零 [M]背景音樂 [ESC]結束遊戲";

            //生成方塊：設定方塊尺寸、隨機顏色、依序由上而下生成於隨機的軌道上
            for (int i = 0; i < note_number; i++)
            {
                note[i] = new PictureBox();
                note[i].Size = new Size(90, 110);
                int k = rnd.Next(200) % drum_number; //可能為 0、1、2，分別代表不同軌道
                note[i].Location = new Point(65 + 70 * k + 100 * k + 5, 95 * i); //依序由上而下生成於隨機的軌道上
                note[i].BackColor = Color.FromArgb((rnd.Next(200) + 120 - 8 * i + 30 * i) % 255,
                                                    (rnd.Next(200) + 130 + 7 * k - 2 * i + 30 * i) % 255,
                                                    (rnd.Next(200) + 50 + 7 * i + 30 * i) % 255); //隨機顏色
                note[i].Tag = "block";
                this.Controls.Add(note[i]);
                note[i].BringToFront();
            }
            //生成玩家：設定方塊尺寸、顏色、依序由左而右生成於軌道上
            for (int i = 0; i < drum_number; i++)
            {
                drum[i] = new PictureBox();
                drum[i].Size = new Size(100, 100);
                drum[i].Location = new Point(65 + 70 * i + 100 * i, 650);

                drum[i].BackColor = Color.FromArgb(150, 102, 86);
                this.Controls.Add(drum[i]);
                drum[i].BringToFront();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            wplayer.URL = "bgm.mp3";
            wplayer.settings.volume = 50;
            wplayer.controls.play();
            wplayer.settings.autoStart = true;
            wplayer.settings.playCount = 1000;
        }
        private void Hit(int right)
        {
            if (note[now].Right == right && note[now].Top == 570)
            {
                sc++;
                label1.Text = "Now : " + sc.ToString();
                sp2.Play();
                int k = rnd.Next(20) % drum_number;
                note[now].Location = new Point(65 + 70 * k + 100 * k + 5, -95);
                note[now].BackColor = Color.FromArgb((rnd.Next(200) + 120 - 8 * k + 30 * now) % 255, (rnd.Next(200) + 130 + 7 * k - 2 * now + 30 * now) % 255, (rnd.Next(200) + 50 + 7 * k) % 255);
                for (int i = 0; i < note_number; i++)
                    note[i].Top += 95;
                if (now == 0)
                    now = note_number - 1;
                else
                    now--;
                if (rnd.Next(8) == 0 && now > 0)
                {
                    int v = now - 1;
                    note[v].Location = new Point(65 + 70 * k + 100 * k + 5, note[v].Top);
                }

            }
            else
            {
                jump = true;
                sp3.Play();
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //[A][S][D]消除方塊 [R]分數歸零 [M]背景音樂 [ESC]結束遊戲
            if (e.KeyCode == Keys.A && !jump)
            {
                hita = true;
                hits = false;
                hitd = false;
            }
            if (e.KeyCode == Keys.S && !jump)
            {
                hits = true;
                hita = false;
                hitd = false;
            }
            if (e.KeyCode == Keys.D && !jump)
            {
                hitd = true;
                hita = false;
                hits = false;
            }
            if (e.KeyCode == Keys.R)
            {
                sc = 0;
                label1.Text = "Now : " + sc.ToString();
            }
            if (e.KeyCode == Keys.M)
            {
                if (wplayer.settings.volume == 50)
                {
                    wplayer.settings.volume = 0;
                }
                else
                    wplayer.settings.volume = 50;
            }
            if (e.KeyCode == Keys.Escape) { Application.Exit(); }
            //160 330 500 
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (hita)
            {
                hita = false;
                Hit(160);
                drum[0].BackColor = Color.FromArgb(255, 255, 0);
            }
            else
            {
                drum[0].BackColor = Color.FromArgb(150, 102, 86);
            }
            if (hits)
            {
                hits = false;
                Hit(330);
                drum[1].BackColor = Color.FromArgb(255, 0, 255);
            }
            else
            {
                drum[1].BackColor = Color.FromArgb(150, 102, 86);
            }
            if (hitd)
            {
                hitd = false;
                Hit(500);
                drum[2].BackColor = Color.FromArgb(0, 255, 255);
            }
            else
            {
                drum[2].BackColor = Color.FromArgb(150, 102, 86);
            }

            if (jump)
            {
                if (note[now].Top > 540 && !up)
                {
                    note[now].Top -= 20;
                }
                else
                {
                    up = true;
                    note[now].Top += 20;
                }

                if (note[now].Top == 570)
                {
                    jump = false;
                    up = false;
                }
            }
        }
    }


}
